package com.company;

public class AbsoluteValue {

    public static void main(String[] args) {

        int digit = -45;
        boolean digitIsMoreThanZero = digit > 0;
        System.out.print(digitIsMoreThanZero ? "|" + digit + "|" : "|" + -digit + "|");

    }
}
