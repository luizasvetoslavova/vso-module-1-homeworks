package com.company;

import java.util.Scanner;

public class degreesTo1000 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Въведи число: ");
        int number = scanner.nextInt();

        System.out.println(number);

        int counter = 0;
        long multipliedNumber = number * number;

        while(counter <= 1000){
            System.out.println(multipliedNumber);
            multipliedNumber = multipliedNumber * number;
            counter++;
        }

    }

}
