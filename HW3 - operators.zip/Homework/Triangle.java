package com.company;

import java.util.Scanner;

public class Triangle {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Insert side A: ");
        int sideA = scanner.nextInt();
        System.out.print("Insert side B: ");
        int sideB = scanner.nextInt();
        System.out.print("Insert side C: ");
        int sideC = scanner.nextInt();

        boolean aIsAppropriateNumber = sideA > 0 && sideA < sideB + sideC;
        boolean bIsAppropriateNumber = sideB > 0 && sideB < sideA + sideC;
        boolean cIsAppropriateNumber = sideC > 0 && sideC < sideB + sideA;
        boolean triangleIsPossible = aIsAppropriateNumber && bIsAppropriateNumber && cIsAppropriateNumber;
        System.out.print(triangleIsPossible ? "Triangle exists." : "Triangle doesn't exist.");

    }
}
