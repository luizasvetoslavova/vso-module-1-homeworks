package com.company;

public class sumOfOddColumns {

    public static void main(String[] args) {

        int[][] matrix = {
                {16, 64, 42, 53, 42, 11},
                {98, 33, 19, 63, 69, 21},
                {53, 64, 33, 91, 14, 39},
                {22, 23, 87, 88, 35, 50},
                {99, 17, 60, 63, 39, 74},
                {12, 27, 89, 45, 63, 88},
        };

        int counter = 0;
        for (int rows = 1; rows < matrix.length; rows++) {
            for (int cols = 0; cols < matrix[rows].length; cols++) {
                if (rows % 2 != 0) {
                    System.out.print(matrix[cols][rows - 1] + ", ");
                    counter += matrix[cols][rows - 1];
                }
            }
            System.out.println((rows % 2 != 0) ? ("the sum of the elements is: " + counter) : "");
            counter = 0;
        }
    }
}
