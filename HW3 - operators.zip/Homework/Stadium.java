package com.company;

import java.util.Scanner;

public class Stadium {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Insert capacity: ");
        String capacity = scanner.nextLine();
        int capacityInInt = Integer.parseInt(capacity);
        System.out.println("Insert lights presence (Yes or No): ");
        String lights = scanner.nextLine();

        boolean hasLicense = capacityInInt > 35000 || lights == "Yes";
        System.out.print(hasLicense ? "Стадионът има лиценз." : "Стадионът няма лиценз.");

    }
}
