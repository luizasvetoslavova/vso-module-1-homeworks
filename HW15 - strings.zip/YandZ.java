package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class YandZ {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please, insert only one space between words: ");
        String text = scanner.nextLine();
        System.out.println(sumAppropriateWords(text));
    }

    public static int sumAppropriateWords(String text) {
        String[] separateWords = text.split(" ");
        int counter = 0;
        for (int i = 0; i <= separateWords.length - 1; i++) {
            if (Character.toString(separateWords[i].charAt(separateWords[i].length() - 1))
                    .equalsIgnoreCase("y")
                    || Character.toString(separateWords[i].charAt(separateWords[i].length() - 1))
                    .equalsIgnoreCase("z")) {
                counter++;
            }
        }
        return counter;
    }
}
