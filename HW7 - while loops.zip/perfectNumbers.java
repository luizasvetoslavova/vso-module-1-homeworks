package com.company;

import java.util.Scanner;

public class perfectNumbers {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int insertNumber = scanner.nextInt();

        int divider = 1;
        int collected = 0;

        while (divider < insertNumber) {
            if (insertNumber % divider == 0 && divider < insertNumber) {
                collected += divider;
            }
            divider++;
        }

        if (collected == insertNumber) {
            System.out.print("It is perfect!");
        } else {
            System.out.print(insertNumber + " is not perfect!");
        }
    }

}
