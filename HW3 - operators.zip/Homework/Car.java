package com.company;

import java.util.Scanner;

public class Car {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Insert the age of the car: ");
        byte carAge = scanner.nextByte();
        System.out.print("Insert the price of the car: ");
        int price = scanner.nextInt();

        boolean isCarHighClass = carAge > 5 && price > 20000 || carAge <= 5 && price > 40000;
        System.out.print(isCarHighClass ? "Автомобилът е от висок клас." : "Автомобилът е от нисък клас.");

    }
}

