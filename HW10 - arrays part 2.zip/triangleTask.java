package com.company;

import java.util.Scanner;

public class triangleTask {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        int[][] triangle = new int[n][n + 2];

        for (int rows = 0; rows < triangle.length * 2; rows += 2) {
            for (int stars = 0; stars <= rows; stars++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
}
