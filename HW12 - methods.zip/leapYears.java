package com.company;

import java.util.Scanner;

public class leapYears {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Year: ");
        int number = scanner.nextInt();
        System.out.print(isYearLeap(number));
    }

    public static boolean isYearLeap(int year) {
        if(year % 4 == 0) {
            return true;
        }
        return false;
    }
}
