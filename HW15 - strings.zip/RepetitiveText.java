package com.company;

import java.util.Scanner;

public class RepetitiveText {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Text: ");
        String text = scanner.nextLine();
        System.out.print("Search: ");
        String repetitiveText = scanner.nextLine();
        System.out.print(sumRepetitiveTexts(text, repetitiveText));
    }

    public static int sumRepetitiveTexts(String text, String repetitiveText) {
        int counter = 0;
        for (int i = 0; i < text.length() - repetitiveText.length() + 1; i++) {
            if ((text.substring(i, i + repetitiveText.length())).equalsIgnoreCase(repetitiveText)) {
                counter++;
            }
        }
        return counter;
    }
}
