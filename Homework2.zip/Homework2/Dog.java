package com.company;

public class Dog {
// class contains both homework 2 & 3

    public static void main(String[] args) {
        String name = "Гошко";
        String breed = "дакел";
        String ownerName = "Гошо Лошия";
        byte humanyears = 2;
        byte dogyears = 14;
        String gender = "мъжки";
        String colour = "кафяв";
        String specialMarks = "";
        String companion = "Петя";
        String exCompanions = "Джеси и Кира";
        String offspring = "Има 11 деца";

        System.out.println("-----------------------------------------------------");
        System.out.println("Куче: " + name + ", " + breed + ", " + colour);
        System.out.println("Собственост на: " + ownerName);
        System.out.println(offspring);
        System.out.println("-----------------------------------------------------");
    }
}
