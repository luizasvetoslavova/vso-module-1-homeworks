package com.company;

import java.util.Random;
import java.util.Scanner;

public class randomsModified {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Random rand = new Random();
        int randomNumber = rand.nextInt(20) + 1;

        System.out.print("Your assumption: ");
        int assumption = scanner.nextInt();

        while (assumption != randomNumber) {
            if(assumption > randomNumber) {
                System.out.print("Too high! Try again: ");
            } else {
                System.out.print("Too low! Try again: ");
            }
            int secondAssumption = scanner.nextInt();
            assumption = secondAssumption;
        }
        if (assumption == randomNumber) {
            System.out.print("You guessed right, " + randomNumber + " is the correct number!");
        }

    }
}


