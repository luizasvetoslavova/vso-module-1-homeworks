package com.company;

import java.util.Scanner;

public class MagicSquareNew {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("The side of your square: ");
        int side = scanner.nextInt();
        int[][] square = new int[side][side];

        insertSquareComponents(square, side);
        printSquare(square, side);
        System.out.println(isSquareMagic(square, side));
    }

    public static void insertSquareComponents(int[][] square, int side) {
        System.out.println("Please tap \"Enter\" between the components of the square side. " +
                "The new rows will be automatically separated by an empty line. \n" +
                "Components: ");

        Scanner scanner = new Scanner(System.in);
        for (int rows = 0; rows < side; rows++) {
            for (int columns = 0; columns < side; columns++) {
                square[rows][columns] = scanner.nextInt();
            }
            System.out.println();
        }
    }

    public static void printSquare(int[][] square, int side) {
        int counter = 0;

        for (int rows = 0; rows < side; rows++) {
            for (int columns = 0; columns < side; columns++) {
                counter += square[rows][columns];
                System.out.print(square[rows][columns] + "  ");
            }
            counter = 0;
            System.out.println();
        }
        System.out.println();
    }

    public static String isSquareMagic(int[][] square, int side) {
        if (sumRows(square, side) == sumColumns(square, side)
                && sumColumns(square, side) == sumFirstDiagonal(square, side)
                && sumFirstDiagonal(square, side) == sumSecondDiagonal(square, side)) {
            return "We have a magic square here!";
        } else {
            return "I don't see any magic squares here.";
        }
    }

    public static int sumRows(int[][] square, int side) {
        int counter = 0;
        int rowsFinalSum = 0;

        for (int rows = 0; rows < side; rows++) {
            for (int columns = 0; columns < side; columns++) {
                counter += square[rows][columns];
            }
            if (rows > 0 && rowsFinalSum != counter) {
                break;
            } else {
            }
            rowsFinalSum = counter;
            counter = 0;
        }
        return rowsFinalSum;
    }

    public static int sumColumns(int[][] square, int side) {
        int counter = 0;
        int columnsFinalSum = 0;

        for (int columns = 0; columns < side; columns++) {
            for (int rows = 0; rows < side; rows++) {
                columnsFinalSum += square[rows][columns];
            }
            if (columns > 0 && columnsFinalSum != counter) {
                break;
            }
            columnsFinalSum = counter;
            counter = 0;
        }
        return columnsFinalSum;
    }

    public static int sumFirstDiagonal(int[][] square, int side) {
        int diagonalSum = 0;

        for (int firstDiagonal = 0; firstDiagonal < side; firstDiagonal++) {
            diagonalSum += square[firstDiagonal][firstDiagonal];
        }
        return diagonalSum;
    }

    public static int sumSecondDiagonal(int[][] square, int side) {
        int diagonalSum = 0;

        for (int i = 0; i < square.length; i++) {
            diagonalSum += square[square.length - 1 - i][i];
        }
        return diagonalSum;
    }
}
