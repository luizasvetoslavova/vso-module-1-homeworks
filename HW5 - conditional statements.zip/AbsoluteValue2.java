package com.company;

import java.util.Scanner;

public class AbsoluteValue2 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        double n = scanner.nextDouble();

        double difference = (n - 21);

        if (difference >= 0 && difference <= 21) {
            System.out.print("|" + difference + "|");

        } else if (difference < 0 && difference <= 21) {
            System.out.print("|" + (- difference) + "|");

        } else if (difference >= 0 && difference > 21) {
            System.out.print("|" + (difference * 2) + "|");

        } else if (difference < 0 && difference > 21){
            System.out.print("|" + ((- difference) * 2) + "|");
        }
    }
}
