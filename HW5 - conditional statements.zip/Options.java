package com.company;

import java.util.Scanner;

public class Options {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int option = scanner.nextInt();

        int a = 16;
        int b = 1;

        switch (option) {
            case 1:
                System.out.print(a + b);
                break;
            case 2:
                System.out.print(a - b);
                break;
            case 3:
                System.out.print(b - 1);
                break;
            case 4:
                System.out.print(a * b);
                break;
            case 5:
                System.out.print(a / b);
                break;
            case 6:
                System.out.print(b / a);
                break;
            default:
                System.out.print("Грешка.");
        }

    }
}
