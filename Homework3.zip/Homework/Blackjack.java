package com.company;

public class Blackjack {

    public static void main(String[] args) {

        int a = 54;
        int b = 19;
        boolean aIsLessOrEqualsTwentyOne = a <= 21;
        boolean bIsLessOrEqualsTwentyOne = b <= 21;
        boolean aIsCloserToTwentyOne = (21 - a) > (21 - b);
        boolean bIsCloserToTwentyOne =  (21 - b) > (21 - a);
        boolean aIsLessAndCloserToTwentyOne = aIsLessOrEqualsTwentyOne == true && aIsCloserToTwentyOne == true;
        boolean bIsLessAndCloserToTwentyOne = bIsLessOrEqualsTwentyOne == true && bIsCloserToTwentyOne == true;
        boolean bothNumbersAreMoreThanTwentyOne = a > 21 && b > 21;
        System.out.print(aIsLessAndCloserToTwentyOne ? a : "");
        System.out.print(bIsLessAndCloserToTwentyOne ? b : "");
        System.out.print(bothNumbersAreMoreThanTwentyOne ? "0" : "");
        
    }
}

