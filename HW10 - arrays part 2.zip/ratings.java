package com.company;

import java.util.Arrays;

public class ratings {

    public static void main(String[] args) {

        int[] reviews = {4, 6, 2, 5, 7, 9, 4, 8, 6, 9, 3, 7};

        for (int i = 0; i < reviews.length; i++) {
            for (int j = 0; j < reviews.length - 1; j++) {
                if (reviews[j] > reviews[j + 1]) {
                    int replace = reviews[j];
                    reviews[j] = reviews[j + 1];
                    reviews[j + 1] = replace;
                }
            }
        }
        System.out.print(Arrays.toString(reviews));
    }
}
