package com.company;

import java.util.Scanner;

public class daysOfTheWeek {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Число: ");
        int dayIndex = scanner.nextInt();
        System.out.print(daysOfTheWeek(dayIndex));
    }

    public static String daysOfTheWeek(int number) {
            switch (number) {
                case 1:
                    return "Понеделник";
                case 2:
                    return "Вторник";
                case 3:
                    return "Сряда";
                case 4:
                    return "Четвъртък";
                case 5:
                    return "Петък";
                case 6:
                    return "Събота";
                case 7:
                    return "Неделя";
            }
        return "Maybe in another universe.";
    }
}