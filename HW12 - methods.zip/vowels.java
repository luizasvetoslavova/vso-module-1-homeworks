package com.company;

import java.util.Scanner;

public class vowels {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Letter: ");
        char letter = scanner.next(".").charAt(0); // using this command to take exactly one symbol from the console
        System.out.print(isAVowel(letter));
    }

    public static boolean isAVowel(char letter) {
        if (letter == 'A' || letter == 'a' || letter == 'E' || letter == 'e' || letter == 'I' || letter == 'i' || letter == 'O' || letter == 'o' || letter == 'U' || letter == 'u' || letter == 'Y' || letter == 'y') {
            return true;
        }
        return false;
    }
}
