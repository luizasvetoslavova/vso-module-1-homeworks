package com.company;

import java.util.Scanner;

public class compareNumbers {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int[] array = new int[10];
        for (int i = 0; i < array.length; i++) {
            int a = scanner.nextInt();
            array[i] = a;
        }
        printNumbers(array);
    }

    public static void printNumbers(int[] array) {
        for (int j = 0; j < array.length; j++) {
            System.out.print(array[j]);
            printSigns(j, array);
        }
    }

    public static void printSigns(int j, int[] array) {
        if (j + 1 < array.length) {
            if (array[j] > array[j + 1]) {
                System.out.print(" > ");
            } else if (array[j] == array[j + 1]) {
                System.out.print(" = ");
            } else {
                System.out.print(" < ");
            }
        }
    }
}
