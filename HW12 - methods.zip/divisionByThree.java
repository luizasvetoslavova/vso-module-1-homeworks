package com.company;

import java.util.Scanner;

public class divisionByThree {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int digitOne = scanner.nextInt();
        int digitTwo = scanner.nextInt();
        System.out.print(isRemainderSame(digitOne, digitTwo));
    }

    public static boolean isRemainderSame(int a, int b) {
        if (a % 3 == b % 3) {
            return true;
        }
        return false;
    }

}
