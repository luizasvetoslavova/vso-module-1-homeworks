package com.company;

public class SwapValues {

    public static void main(String[] args) {
        int a = 5;
        int b = 11;
        a = 11;
        b = 5;
        System.out.println(a);
        System.out.println(b);

    }
}
