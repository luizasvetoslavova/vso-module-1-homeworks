package com.company;

import java.util.Random;
import java.util.Scanner;

public class randoms {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Random rand = new Random();
        int randomNumber = rand.nextInt(20) + 1;

        System.out.print("Your assumption: ");
        int assumption = scanner.nextInt();

        while (assumption != randomNumber) {
            System.out.print("Oops! Wrong number! Try again: ");
            int secondAssumption = scanner.nextInt();
            assumption = secondAssumption;
        }
        if (assumption == randomNumber) {
            System.out.print("You guessed right, " + randomNumber + " is the correct number!");
        }

        }
    }



