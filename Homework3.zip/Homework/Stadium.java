package com.company;

public class Stadium {

    public static void main(String[] args) {

        int capacity = 35001;
        boolean hasLights = true;
        boolean hasLicense = capacity > 35000 || hasLights == true;
        System.out.print(hasLicense ? "Стадионът има лиценз." : "Стадионът няма лиценз.");

    }
}
