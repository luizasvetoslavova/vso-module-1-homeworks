package com.company;

public class Triangle {

    public static void main(String[] args) {

        int a = 65;
        int b = 68;
        int c = 24;
        boolean aIsAppropriateNumber = a > 0 && a < b + c;
        boolean bIsAppropriateNumber = b > 0 && b < a + c;
        boolean cIsAppropriateNumber = c > 0 && c < b + a;
        boolean triangleIsPossible = aIsAppropriateNumber && bIsAppropriateNumber && cIsAppropriateNumber;
        System.out.print(triangleIsPossible ? "Триъгълникът съществува." : "Триъгълникът не съществува.");

    }
}
