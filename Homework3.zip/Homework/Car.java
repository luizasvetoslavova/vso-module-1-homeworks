package com.company;

public class Car {

    public static void main(String[] args) {

        byte carAge = 5;
        int price = 25000;
        boolean isCarHighClass = carAge > 5 && price > 20000 || carAge <= 5 && price > 40000;
        System.out.print(isCarHighClass ? "Автомобилът е от висок клас." : "Автомобилът е от нисък клас.");

    }
}

