package com.company;

import java.util.Scanner;

public class NumberToText {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int inputNumber = scanner.nextInt();

        int firstDigit = inputNumber / 100;
        int secondDigit = (inputNumber / 10) % 10;
        int thirdDigit = (inputNumber % 100) % 10;

        String compound = "и ";
        String forTeens = "на";
        String tens = "десет ";
        String hundreds = "стотин ";
        String hundred = "сто ";
        String hundredsBelow400 = "ста ";

        String one = "едно";
        String two = "две";
        String twoCombined = "два";
        String three = "три";
        String four = "четири";
        String five = "пет";
        String six = "шест";
        String seven = "седем";
        String eight = "осем";
        String nine = "девет";

        boolean canBeDividedBy10 = (inputNumber % 10) == 0;
        boolean isBetween100and1000 = inputNumber >= 100 && inputNumber < 1000;
        boolean isTeenAbove100 = ((inputNumber > 110 && inputNumber < 120) || (inputNumber > 210 && inputNumber < 220) || (inputNumber > 310 && inputNumber < 320) || (inputNumber > 410 && inputNumber < 420) || (inputNumber > 510 && inputNumber < 520) || (inputNumber > 610 && inputNumber < 620) || (inputNumber > 710 && inputNumber < 720) || (inputNumber > 810 && inputNumber < 820) || (inputNumber > 910 && inputNumber < 920)) && isBetween100and1000;
        boolean isTeen = (inputNumber > 10 && inputNumber < 20);

        // 0-19 and 1000
        switch (inputNumber) {
            case 0:
                System.out.print("нула");
                break;
            case 1:
                System.out.print(one);
                break;
            case 2:
                System.out.print(two);
                break;
            case 3:
                System.out.print(three);
                break;
            case 4:
                System.out.print(four);
                break;
            case 5:
                System.out.print(five);
                break;
            case 6:
                System.out.print(six);
                break;
            case 7:
                System.out.print(seven);
                break;
            case 8:
                System.out.print(eight);
                break;
            case 9:
                System.out.print(nine);
                break;
            case 10:
                System.out.print(tens);
                break;
            case 11:
                System.out.print("еди" + forTeens + tens);
                break;
            case 12:
                System.out.print(twoCombined + forTeens + tens);
                break;
            case 13:
                System.out.print(three + forTeens + tens);
                break;
            case 14:
                System.out.print(four + forTeens + tens);
                break;
            case 15:
                System.out.print(five + forTeens + tens);
                break;
            case 16:
                System.out.print(six + forTeens + tens);
                break;
            case 17:
                System.out.print(seven + forTeens + tens);
                break;
            case 18:
                System.out.print(eight + forTeens + tens);
                break;
            case 19:
                System.out.print(nine + forTeens + tens);
                break;
            case 1000:
                System.out.print("хиляда");
                break;
        }

        // 20-100
        if (inputNumber >= 20 && inputNumber < 30) {
            System.out.print(twoCombined + tens);
        } else if (inputNumber >= 30 && inputNumber < 40) {
            System.out.print(three + tens);
        } else if (inputNumber >= 40 && inputNumber < 50) {
            System.out.print(four + tens);
        } else if (inputNumber >= 50 && inputNumber < 60) {
            System.out.print(five + tens);
        } else if (inputNumber >= 60 && inputNumber < 70) {
            System.out.print(six + tens);
        } else if (inputNumber >= 70 && inputNumber < 80) {
            System.out.print(seven + tens);
        } else if (inputNumber >= 80 && inputNumber < 90) {
            System.out.print(eight + tens);
        } else if (inputNumber >= 90 && inputNumber < 100) {
            System.out.print(nine + tens);
        }

        // "teens" above 100
        if (inputNumber > 110 && inputNumber < 120) {
            System.out.print(hundred + compound);
        } else if (inputNumber > 210 && inputNumber < 220) {
            System.out.print(two + hundredsBelow400 + compound);
        } else if (inputNumber > 310 && inputNumber < 320) {
            System.out.print(three + hundredsBelow400 + compound);
        } else if (inputNumber > 410 && inputNumber < 420) {
            System.out.print(four + hundreds + compound);
        } else if (inputNumber > 510 && inputNumber < 520) {
            System.out.print(five + hundreds + compound);
        } else if (inputNumber > 610 && inputNumber < 620) {
            System.out.print(six + hundreds + compound);
        } else if (inputNumber > 710 && inputNumber < 720) {
            System.out.print(seven + hundreds + compound);
        } else if (inputNumber > 810 && inputNumber < 820) {
            System.out.print(eight + hundreds + compound);
        } else if (inputNumber > 910 && inputNumber < 920) {
            System.out.print(nine + hundreds + compound);
        }

        if (isTeenAbove100 && thirdDigit == 1) {
            System.out.print("еди" + forTeens + tens);
        } else if (isTeenAbove100 && thirdDigit == 2) {
            System.out.print(twoCombined + forTeens + tens);
        } else if (isTeenAbove100 && thirdDigit == 3) {
            System.out.print(three + forTeens + tens);
        } else if (isTeenAbove100 && thirdDigit == 4) {
            System.out.print(four + forTeens + tens);
        } else if (isTeenAbove100 && thirdDigit == 5) {
            System.out.print(five + forTeens + tens);
        } else if (isTeenAbove100 && thirdDigit == 6) {
            System.out.print(six + forTeens + tens);
        } else if (isTeenAbove100 && thirdDigit == 7) {
            System.out.print(seven + forTeens + tens);
        } else if (isTeenAbove100 && thirdDigit == 8) {
            System.out.print(eight + forTeens + tens);
        } else if (isTeenAbove100 && thirdDigit == 9) {
            System.out.print(nine + forTeens + tens);
        }

        // 100-999
        if (inputNumber >= 100 && inputNumber < 200 && !isTeen && !isTeenAbove100) {
            System.out.print(hundred);
        } else if (!isTeenAbove100 && !isTeen && firstDigit == 2) {
            System.out.print(two + hundredsBelow400);
        } else if (!isTeenAbove100 && !isTeen && firstDigit == 3) {
            System.out.print(three + hundredsBelow400);
        } else if (!isTeenAbove100 && !isTeen && firstDigit == 4) {
            System.out.print(four + hundreds);
        } else if (!isTeenAbove100 && !isTeen && firstDigit == 5) {
            System.out.print(five + hundreds);
        } else if (!isTeenAbove100 && !isTeen && firstDigit == 6) {
            System.out.print(six + hundreds);
        } else if (!isTeenAbove100 && !isTeen && firstDigit == 7) {
            System.out.print(seven + hundreds);
        } else if (!isTeenAbove100 && !isTeen && firstDigit == 8) {
            System.out.print(eight + hundreds);
        } else if (!isTeenAbove100 && !isTeen && firstDigit == 9) {
            System.out.print(nine + hundreds);
        }

        if (isBetween100and1000 && secondDigit == 1 && thirdDigit == 0) {
            System.out.print(compound + tens);
        } else if (isBetween100and1000 && secondDigit == 2) {
            System.out.print(canBeDividedBy10 ? (compound + twoCombined + tens) : (twoCombined + tens));
        } else if (isBetween100and1000 && secondDigit == 3) {
            System.out.print(canBeDividedBy10 ? (compound + three + tens) : (three + tens));
        } else if (isBetween100and1000 && secondDigit == 4) {
            System.out.print(canBeDividedBy10 ? (compound + four + tens) : (four + tens));
        } else if (isBetween100and1000 && secondDigit == 5) {
            System.out.print(canBeDividedBy10 ? (compound + five + tens) : (five + tens));
        } else if (isBetween100and1000 && secondDigit == 6) {
            System.out.print(canBeDividedBy10 ? (compound + six + tens) : (six + tens));
        } else if (isBetween100and1000 && secondDigit == 7) {
            System.out.print(canBeDividedBy10 ? (compound + seven + tens) : (seven + tens));
        } else if (isBetween100and1000 && secondDigit == 8) {
            System.out.print(canBeDividedBy10 ? (compound + eight + tens) : (eight + tens));
        } else if (isBetween100and1000 && secondDigit == 9) {
            System.out.print(canBeDividedBy10 ? (compound + nine + tens) : (nine + tens));
        }

        if (!isTeenAbove100 && !isTeen && thirdDigit == 1) {
            System.out.print(compound + one);
        } else if (!isTeenAbove100 && !isTeen && thirdDigit == 2) {
            System.out.print(compound + two);
        } else if (!isTeenAbove100 && !isTeen && thirdDigit == 3) {
            System.out.print(compound + three);
        } else if (!isTeenAbove100 && !isTeen && thirdDigit == 4) {
            System.out.print(compound + four);
        } else if (!isTeenAbove100 && !isTeen && thirdDigit == 5) {
            System.out.print(compound + five);
        } else if (!isTeenAbove100 && !isTeen && thirdDigit == 6) {
            System.out.print(compound + six);
        } else if (!isTeenAbove100 && !isTeen && thirdDigit == 7) {
            System.out.print(compound + seven);
        } else if (!isTeenAbove100 && !isTeen && thirdDigit == 8) {
            System.out.print(compound + eight);
        } else if (!isTeenAbove100 && !isTeen && thirdDigit == 9) {
            System.out.print(compound + nine);
        }
    }
}
