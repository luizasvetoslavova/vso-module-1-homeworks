package com.company;

import java.util.Scanner;

public class divisionTask3 {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int first = scanner.nextInt();
        int second = scanner.nextInt();
        int third = scanner.nextInt();
        System.out.print(canBeDivided(first, second, third));

    }

    public static boolean canBeDivided(int a, int b, int c) {
        if (a % b == 0 && a % c == 0) {
            return true;
        }
        return false;
    }
}
