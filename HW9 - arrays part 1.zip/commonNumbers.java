package com.company;

import java.util.Arrays;

public class commonNumbers {

    public static void main(String[] args) {

        int[] numberArrayOne = {64, 52, 643, 7, 9, 444, 84};
        int[] numberArrayTwo = {99, 31, 0, 7, 52};

        int resultCounter = 0;
        int[] result = new int[numberArrayOne.length];

        for (int arrayOneIndex = 0; arrayOneIndex < numberArrayOne.length; arrayOneIndex++) {
            for (int arrayTwoIndex = 0; arrayTwoIndex < numberArrayTwo.length; arrayTwoIndex++) {
                if (numberArrayOne[arrayOneIndex] == numberArrayTwo[arrayTwoIndex]) {
                    result[resultCounter] = numberArrayTwo[arrayTwoIndex];
                    resultCounter++;
                }
            }
        }

        int[] onlyNumbers = new int[resultCounter];
        for (int index = 0; index < resultCounter; index++) {
            onlyNumbers[index] = result[index];
        }
        System.out.print(Arrays.toString(onlyNumbers));
    }
}
