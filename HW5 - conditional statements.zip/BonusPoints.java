package com.company;

import java.util.InputMismatchException;
import java.util.Scanner;

public class BonusPoints {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        int inputPoints = scanner.nextInt();

        if (inputPoints >= 1 && inputPoints <= 3) {
            System.out.print(inputPoints * 10);

        } else if (inputPoints >= 4 && inputPoints <= 6) {
            System.out.print(inputPoints * 100);

        } else if (inputPoints >= 7 && inputPoints <= 9) {
            System.out.print(inputPoints * 1000);

        } else if (inputPoints == 0 || inputPoints > 9) {
            System.out.print("Грешка");
        }
    }
}
