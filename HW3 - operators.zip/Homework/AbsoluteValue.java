package com.company;

import java.util.Scanner;

public class AbsoluteValue {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Insert number: ");
        int number = scanner.nextInt();

        boolean digitIsMoreThanZero = number > 0;
        System.out.print(digitIsMoreThanZero ? "|" + number + "|" : "|" + -number + "|");

    }
}
