package com.company;

import java.lang.reflect.Array;
import java.util.Arrays;

public class OddAndEvenIndexes {

    public static void main(String[] args) {

        int[] arrayOne = {54, 33, 4, 9, 666, 12};
        int[] arrayTwo = {23, 7, 85, 53, 777, 37};

        int[] result = new int[arrayOne.length];

        for (int index = 0; index < arrayOne.length; index++) {
            if (index % 2 == 0) {
                result[index] = arrayOne[index];
            } else {
                result[index] = arrayTwo[index];
            }
        }
        System.out.print(Arrays.toString(result));
    }
}