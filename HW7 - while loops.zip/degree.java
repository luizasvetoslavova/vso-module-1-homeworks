package com.company;

import java.util.Scanner;

public class degree {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Въведи число: ");
        int number = scanner.nextInt();
        System.out.print("Въведи степен: ");
        int degree = scanner.nextInt();

        int counter = 1;
        int multipliedNumber = 1;

        while (counter <= degree) {
            multipliedNumber = multipliedNumber * number;
            counter++;
        }
        System.out.print("Резултат: " + multipliedNumber);
    }

}