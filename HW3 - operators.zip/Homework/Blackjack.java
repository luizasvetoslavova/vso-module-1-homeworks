package com.company;

import java.util.Scanner;

public class Blackjack {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("Insert a: ");
        int a = scanner.nextInt();
        System.out.print("Insert b: ");
        int b = scanner.nextInt();


        boolean aIsLessOrEqualsTwentyOne = a <= 21;
        boolean bIsLessOrEqualsTwentyOne = b <= 21;
        boolean aIsCloserToTwentyOne = (21 - a) < (21 - b);
        boolean bIsCloserToTwentyOne = (21 - b) < (21 - a);
        boolean aIsLessAndCloserToTwentyOne = aIsLessOrEqualsTwentyOne == true && aIsCloserToTwentyOne == true;
        boolean bIsLessAndCloserToTwentyOne = bIsLessOrEqualsTwentyOne == true && bIsCloserToTwentyOne == true;
        boolean bothNumbersAreMoreThanTwentyOne = a > 21 && b > 21;

        System.out.print(aIsLessAndCloserToTwentyOne ? a : "");
        System.out.print(bIsLessAndCloserToTwentyOne ? b : "");
        System.out.print(bothNumbersAreMoreThanTwentyOne ? "0" : "");

    }
}

