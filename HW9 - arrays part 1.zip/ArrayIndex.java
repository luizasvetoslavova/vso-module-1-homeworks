package com.company;

import java.util.Arrays;

public class ArrayIndex {

    public static void main(String[] args) {
        int[] numbersBefore = {1, 65, 5, 333, 8, 4583};
        System.out.println(Arrays.toString(numbersBefore));

        int[] numbersAfter = new int[numbersBefore.length];

        for (int index = 0; index < numbersBefore.length; index++) {
            numbersAfter[index] = numbersBefore[index] * index;
        }
        System.out.print(Arrays.toString(numbersAfter));
    }
}