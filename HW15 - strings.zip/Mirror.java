package com.company;

import java.util.Arrays;
import java.util.Scanner;

public class Mirror {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String text = scanner.nextLine();

        System.out.print(findMirroredPart(text));
    }

    public static String findMirroredPart(String text) {
        String mirroredPart = "";
        for (int i = 0; i < text.length(); i++) {
            if (Character.toString(text.charAt(i)).equalsIgnoreCase(Character.toString(text.charAt(text.length() - 1 - i)))) {
                mirroredPart += Character.toString(text.charAt(i));
            } else {
                break;
            }
        }
        if (mirroredPart.equals("")) {
            return "No mirrored part";
        }
        return mirroredPart.toLowerCase();
    }
}