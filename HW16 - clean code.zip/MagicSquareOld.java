package com.company;

import java.util.Scanner;

public class MagicSquareOld {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.print("The side of your square: ");
        int side = scanner.nextInt();
        int[][] square = new int[side][side];

        // side
        System.out.println("Please tap \"Enter\" between the components of the square side. The new rows will be automatically separated by an empty line.");
        System.out.println("Rows: ");
        for (int rows = 0; rows < side; rows++) {
            for (int columns = 0; columns < side; columns++) {
                square[rows][columns] = scanner.nextInt();
            }
            System.out.println();
        }

        // print square
        int counter = 0;
        System.out.println("Your square: ");
        for (int rows = 0; rows < side; rows++) {
            for (int columns = 0; columns < side; columns++) {
                counter += square[rows][columns];
                System.out.print(square[rows][columns] + "  ");
            }
            counter = 0;
            System.out.println();
        }
        System.out.println();

        // rows
        counter = 0;
        int rowsCounter = 0;
        for (int rows = 0; rows < side; rows++) {
            for (int columns = 0; columns < side; columns++) {
                counter += square[rows][columns];
            }
            if (rows > 0 && rowsCounter != counter) {
                break;
            } else {
            }
            rowsCounter = counter;
            counter = 0;
        }

        // columns
        counter = 0;
        int columnsCounter = 0;
        for (int columns = 0; columns < side; columns++) {
            for (int rows = 0; rows < side; rows++) {
                columnsCounter += square[rows][columns];
            }
            if (columns > 0 && columnsCounter != counter) {
                break;
            }
            columnsCounter = counter;
            counter = 0;
        }

        // first diagonal
        int firstDiagCounter = 0;
        for (int firstDiagonal = 0; firstDiagonal < side; firstDiagonal++) {
            firstDiagCounter += square[firstDiagonal][firstDiagonal];
        }

        // second diagonal
        int secondDiagCounter = 0;
        for (int i = 0; i < square.length; i++) {
            secondDiagCounter += square[square.length - 1 - i][i];
        }

        // sum
        if (rowsCounter == columnsCounter && columnsCounter == firstDiagCounter && firstDiagCounter == secondDiagCounter) {
            System.out.print("We have a magic square here!");
        } else {
            System.out.print("I don't see any magic squares here.");
        }
    }
}